import os
import json
import hashlib
import time
import threading
import logging
from datetime import datetime, timedelta
from urllib.request import urlopen, Request
from urllib.error import URLError
from html.parser import HTMLParser
import re
import sqlite3

from flask import Flask, jsonify, request
from flask_cors import CORS
from apscheduler.schedulers.background import BackgroundScheduler

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
log = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

DB_PATH = os.environ.get('DB_PATH', 'veille.db')

# ── Sources ───────────────────────────────────────────────────────────────────
SOURCES = [
    # Europe en Régions
    {"name": "Europe Nouvelle-Aquitaine", "cat": "Europe en Régions", "region": "Nouvelle-Aquitaine", "url": "https://www.europe-en-nouvelle-aquitaine.eu/fr/appels-a-projets.html"},
    {"name": "Europe Occitanie", "cat": "Europe en Régions", "region": "Occitanie", "url": "https://www.europe-en-occitanie.eu/"},
    {"name": "Europe PACA", "cat": "Europe en Régions", "region": "PACA", "url": "https://europe.maregionsud.fr/aides-et-appels-a-projets/projets"},
    {"name": "Europe AURA", "cat": "Europe en Régions", "region": "AURA", "url": "https://www.europeenauvergnerhonealpes.fr/aides-europeennes"},
    {"name": "Europe Bourgogne-FC", "cat": "Europe en Régions", "region": "Bourgogne-FC", "url": "https://www.europe-bfc.eu/nos-aides"},
    {"name": "Europe Centre-Val de Loire", "cat": "Europe en Régions", "region": "Centre-Val de Loire", "url": "https://www.europeocentre-valdeloire.eu/identifier-votre-financement/"},
    {"name": "Europe Bretagne", "cat": "Europe en Régions", "region": "Bretagne", "url": "https://europe.bzh/aides/"},
    {"name": "Europe Normandie", "cat": "Europe en Régions", "region": "Normandie", "url": "https://www.europe-en-normandie.eu/tous-les-financements-par-thematique"},
    {"name": "Europe Hauts-de-France", "cat": "Europe en Régions", "region": "Hauts-de-France", "url": "https://europe-en-hautsdefrance.eu/jai-un-projet/je-trouve-un-financement"},
    {"name": "Europe Grand Est", "cat": "Europe en Régions", "region": "Grand Est", "url": "https://beeurope.grandest.fr/aides/"},
    {"name": "Europe IDF", "cat": "Europe en Régions", "region": "IDF", "url": "https://www.europeidf.fr/jai-un-projet"},
    {"name": "Europe Guadeloupe", "cat": "Europe en Régions", "region": "Guadeloupe", "url": "https://www.europe-guadeloupe.fr/jai-un-projet/les-appels-a-projets/"},
    # Régions
    {"name": "Région Nouvelle-Aquitaine", "cat": "Régions", "region": "Nouvelle-Aquitaine", "url": "https://les-aides.nouvelle-aquitaine.fr/"},
    {"name": "Région Occitanie", "cat": "Régions", "region": "Occitanie", "url": "https://www.laregion.fr/-Toutes-les-aides-"},
    {"name": "Région PACA", "cat": "Régions", "region": "PACA", "url": "https://www.maregionsud.fr/aides-et-appels-a-projets"},
    {"name": "Région AURA", "cat": "Régions", "region": "AURA", "url": "https://www.auvergnerhonealpes.fr/aides"},
    {"name": "Région Bourgogne-FC", "cat": "Régions", "region": "Bourgogne-FC", "url": "https://www.bourgognefranchecomte.fr/guide-des-aides"},
    {"name": "Région Pays de la Loire", "cat": "Régions", "region": "Pays de la Loire", "url": "https://www.paysdelaloire.fr/les-aides"},
    {"name": "Région Centre-Val de Loire", "cat": "Régions", "region": "Centre-Val de Loire", "url": "https://www.centre-valdeloire.fr/le-guide-des-aides-de-la-region-centre-val-de-loire"},
    {"name": "Région Bretagne", "cat": "Régions", "region": "Bretagne", "url": "https://www.bretagne.bzh/aides/"},
    {"name": "Région Normandie", "cat": "Régions", "region": "Normandie", "url": "https://aides.normandie.fr/"},
    {"name": "Région Hauts-de-France", "cat": "Régions", "region": "Hauts-de-France", "url": "https://guide-aides.hautsdefrance.fr/"},
    {"name": "Région Grand Est", "cat": "Régions", "region": "Grand Est", "url": "https://www.grandest.fr/aides/"},
    {"name": "Région IDF", "cat": "Régions", "region": "IDF", "url": "https://www.iledefrance.fr/aides-services"},
    # Opérateurs nationaux
    {"name": "ADEME entreprises", "cat": "Opérateur national", "region": "National", "url": "https://agirpourlatransition.ademe.fr/entreprises/aides-financieres"},
    {"name": "ADEME collectivités", "cat": "Opérateur national", "region": "National", "url": "https://agirpourlatransition.ademe.fr/collectivites/financez-vos-projets"},
    {"name": "Bpifrance", "cat": "Opérateur national", "region": "National", "url": "https://www.bpifrance.fr/nos-solutions/financement/financement-expertise"},
    {"name": "Aides Territoires", "cat": "Opérateur national", "region": "National", "url": "https://aides-territoires.beta.gouv.fr/portails/gnius/"},
    {"name": "France Agrimer", "cat": "Opérateur national", "region": "National", "url": "https://www.franceagrimer.fr/Accompagner/Dispositifs-par-filiere/Aides-nationales/Grandes-cultures"},
    {"name": "CNL", "cat": "Opérateur national", "region": "National", "url": "https://centrenationaldulivre.fr/"},
    {"name": "ANS", "cat": "Opérateur national", "region": "National", "url": "https://www.agencedusport.fr/aides-et-subventions"},
    {"name": "CNM", "cat": "Opérateur national", "region": "National", "url": "https://cnm.fr/aides-financieres/"},
    # DREETS
    {"name": "DREETS Nouvelle-Aquitaine", "cat": "DREETS", "region": "Nouvelle-Aquitaine", "url": "https://nouvelle-aquitaine.dreets.gouv.fr/"},
    {"name": "DREETS Occitanie", "cat": "DREETS", "region": "Occitanie", "url": "https://occitanie.dreets.gouv.fr/"},
    {"name": "DREETS PACA", "cat": "DREETS", "region": "PACA", "url": "https://paca.dreets.gouv.fr/"},
    {"name": "DREETS AURA", "cat": "DREETS", "region": "AURA", "url": "https://auvergne-rhone-alpes.dreets.gouv.fr/"},
    {"name": "DREETS Bretagne", "cat": "DREETS", "region": "Bretagne", "url": "https://bretagne.dreets.gouv.fr/"},
    {"name": "DREETS Normandie", "cat": "DREETS", "region": "Normandie", "url": "https://normandie.dreets.gouv.fr/"},
    {"name": "DREETS Grand Est", "cat": "DREETS", "region": "Grand Est", "url": "https://grand-est.dreets.gouv.fr/"},
    {"name": "DREETS Hauts-de-France", "cat": "DREETS", "region": "Hauts-de-France", "url": "https://hauts-de-france.dreets.gouv.fr/"},
    {"name": "DREETS Pays de la Loire", "cat": "DREETS", "region": "Pays de la Loire", "url": "https://pays-de-la-loire.dreets.gouv.fr/"},
    {"name": "DREETS Bourgogne-FC", "cat": "DREETS", "region": "Bourgogne-FC", "url": "https://bourgogne-franche-comte.dreets.gouv.fr/"},
    {"name": "DRIEETS IDF", "cat": "DREETS", "region": "IDF", "url": "https://idf.drieets.gouv.fr/"},
    # Agences de l'eau
    {"name": "Agence eau Grand Sud-Ouest", "cat": "Agence de l'eau", "region": "Nouvelle-Aquitaine", "url": "https://eau-grandsudouest.fr/aides-financieres"},
    {"name": "Agence eau RMC", "cat": "Agence de l'eau", "region": "AURA", "url": "https://www.eaurmc.fr/jcms/gbr_5503/fr/les-appels-a-projets"},
    {"name": "Agence eau Loire-Bretagne", "cat": "Agence de l'eau", "region": "Bretagne", "url": "https://www.eau-loire-bretagne.fr/sites/agence/home/agence-de-leau/le-12e-programme-2025-2030.html"},
    {"name": "Agence eau Artois-Picardie", "cat": "Agence de l'eau", "region": "Hauts-de-France", "url": "https://www.eau-artois-picardie.fr/les-appels-projets-de-lagence-de-leau"},
    {"name": "Agence eau Rhin-Meuse", "cat": "Agence de l'eau", "region": "Grand Est", "url": "https://www.eau-rhin-meuse.fr/nos-aides"},
    # CARSAT
    {"name": "CARSAT Aquitaine", "cat": "CARSAT", "region": "Nouvelle-Aquitaine", "url": "https://www.carsat-aquitaine.fr/home/partenaires/actualites-partenaire.html"},
    {"name": "CARSAT Occitanie", "cat": "CARSAT", "region": "Occitanie", "url": "https://www.carsat-mp.fr/"},
    {"name": "CARSAT AURA", "cat": "CARSAT", "region": "AURA", "url": "https://www.carsat-auvergne.fr/"},
    {"name": "CARSAT Bourgogne-FC", "cat": "CARSAT", "region": "Bourgogne-FC", "url": "https://www.carsat-bfc.fr/"},
    {"name": "CARSAT Bretagne", "cat": "CARSAT", "region": "Bretagne", "url": "https://www.carsat-bretagne.fr/"},
    {"name": "CARSAT Normandie", "cat": "CARSAT", "region": "Normandie", "url": "https://www.carsat-normandie.fr"},
    {"name": "CARSAT Hauts-de-France", "cat": "CARSAT", "region": "Hauts-de-France", "url": "https://carsat-hdf.fr"},
    {"name": "CARSAT Grand Est", "cat": "CARSAT", "region": "Grand Est", "url": "https://www.carsat-nordest.fr/"},
    {"name": "CGSS Guyane", "cat": "CARSAT", "region": "Guyane", "url": "https://www.cgss-guyane.fr/appel-a-projets/"},
    # CRESS
    {"name": "CRESS Nouvelle-Aquitaine", "cat": "CRESS", "region": "Nouvelle-Aquitaine", "url": "https://www.cress-na.org/appels-a-projets/"},
    # Départements
    {"name": "Hérault (34)", "cat": "Départements", "region": "Occitanie", "url": "https://herault.fr/321-guide-des-aides-et-appels-a-projet.htm"},
    {"name": "Tarn (81)", "cat": "Départements", "region": "Occitanie", "url": "https://www.tarn.fr/guide-des-aides"},
    {"name": "Pyrénées-Orientales (66)", "cat": "Départements", "region": "Occitanie", "url": "https://www.ledepartement66.fr/nos-aides/"},
    {"name": "Val-de-Marne (94)", "cat": "Départements", "region": "IDF", "url": "https://www.valdemarne.fr/le-conseil-departemental/les-appels-a-projets"},
    {"name": "Haute-Savoie (74)", "cat": "Départements", "region": "AURA", "url": "https://hautesavoie.fr/en-pratique/toutes-les-aides-et-subventions/"},
    {"name": "Nord (59)", "cat": "Départements", "region": "Hauts-de-France", "url": "https://inord.lenord.fr/jcms/prd1_676879/les-dispositifs-departementaux"},
    {"name": "Pas-de-Calais (62)", "cat": "Départements", "region": "Hauts-de-France", "url": "https://www.pasdecalais.fr/subventions-departementales"},
    {"name": "Manche (50)", "cat": "Départements", "region": "Normandie", "url": "https://www.manche.fr/guide-des-aides/"},
    {"name": "Morbihan (56)", "cat": "Départements", "region": "Bretagne", "url": "https://www.morbihan.fr/aides-et-services/rechercher-une-aide"},
    {"name": "Ille-et-Vilaine (35)", "cat": "Départements", "region": "Bretagne", "url": "https://www.ille-et-vilaine.fr/les-aides-du-departement"},
    {"name": "Sarthe (72)", "cat": "Départements", "region": "Pays de la Loire", "url": "https://www.sarthe.fr/guide-des-aides"},
    {"name": "Vendée (85)", "cat": "Départements", "region": "Pays de la Loire", "url": "https://www.vendee.fr/guide-des-aides-et-services"},
    {"name": "Maine-et-Loire (49)", "cat": "Départements", "region": "Pays de la Loire", "url": "https://www.maine-et-loire.fr/aides-et-services/professionnels/guide-des-aides"},
    {"name": "Doubs (25)", "cat": "Départements", "region": "Bourgogne-FC", "url": "https://www.doubs.fr/le-departement/appel-a-projets-a-candidatures-ou-appel-a-manifestation-dinteret/"},
    {"name": "Saône-et-Loire (71)", "cat": "Départements", "region": "Bourgogne-FC", "url": "https://www.saoneetloire.fr/guide-des-aides/"},
    {"name": "Landes (40)", "cat": "Départements", "region": "Nouvelle-Aquitaine", "url": "https://www.landes.fr/guide-des-aides"},
    {"name": "Corrèze (19)", "cat": "Départements", "region": "Nouvelle-Aquitaine", "url": "https://www.correze.fr/services-en-ligne/les-aides"},
    {"name": "Dordogne (24)", "cat": "Départements", "region": "Nouvelle-Aquitaine", "url": "https://demarches.dordogne.fr/demarches/profil-entreprises/subventions/"},
    {"name": "Finistère (29)", "cat": "Départements", "region": "Bretagne", "url": "https://www.finistere.fr/aides-et-services/"},
    {"name": "Calvados (14)", "cat": "Départements", "region": "Normandie", "url": "https://www.calvados.fr/accueil/aides--services.html"},
    {"name": "Seine-Maritime (76)", "cat": "Départements", "region": "Normandie", "url": "https://mesdemarches.seinemaritime.fr/category_e_service/subvention/"},
    {"name": "Somme (80)", "cat": "Départements", "region": "Hauts-de-France", "url": "https://www.somme.fr/services/nos-aides/"},
    {"name": "Oise (60)", "cat": "Départements", "region": "Hauts-de-France", "url": "https://oise.fr/information/portail-des-aides-et-subventions-du-conseil-departemental-de-loise"},
    {"name": "Meurthe-et-Moselle (54)", "cat": "Départements", "region": "Grand Est", "url": "https://meurthe-et-moselle.fr/appels-a-projets/"},
    {"name": "Meuse (55)", "cat": "Départements", "region": "Grand Est", "url": "https://www.meuse.fr/information-transversale/guide-des-aides"},
    {"name": "Haute-Marne (52)", "cat": "Départements", "region": "Grand Est", "url": "https://haute-marne.fr/guide-des-aides/"},
    {"name": "Vosges (88)", "cat": "Départements", "region": "Grand Est", "url": "https://www.vosges.fr/mon-departement/appels-a-projets/"},
    {"name": "Ardennes (08)", "cat": "Départements", "region": "Grand Est", "url": "https://www.cd08.fr/aides-et-subventions"},
    {"name": "Aube (10)", "cat": "Départements", "region": "Grand Est", "url": "https://www.aube.fr/18-aides-du-departement.htm"},
    {"name": "Aisne (02)", "cat": "Départements", "region": "Hauts-de-France", "url": "https://aisne.com/aides"},
    {"name": "Indre (36)", "cat": "Départements", "region": "Centre-Val de Loire", "url": "https://www.indre.fr/fr/subventions"},
    {"name": "Loiret (45)", "cat": "Départements", "region": "Centre-Val de Loire", "url": "https://www.loiret.fr/aides"},
    {"name": "Ariège (09)", "cat": "Départements", "region": "Occitanie", "url": "https://ariege.fr/guide-des-aides/"},
]

CAT_COLORS = {
    'Europe en Régions': '#8b5cf6',
    'DREETS': '#f97316',
    'Régions': '#3b82f6',
    'Départements': '#10b981',
    'Opérateur national': '#f59e0b',
    'CARSAT': '#14b8a6',
    "Agence de l'eau": '#06b6d4',
    'CRESS': '#ec4899',
}

# ── Database ───────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hash TEXT UNIQUE NOT NULL,
            title TEXT NOT NULL,
            url TEXT NOT NULL,
            summary TEXT,
            source TEXT,
            cat TEXT,
            region TEXT,
            color TEXT,
            source_url TEXT,
            scraped_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_url TEXT UNIQUE NOT NULL,
            content_hash TEXT,
            last_checked TEXT DEFAULT CURRENT_TIMESTAMP,
            error_count INTEGER DEFAULT 0,
            status TEXT DEFAULT 'pending'
        );
        CREATE INDEX IF NOT EXISTS idx_articles_cat ON articles(cat);
        CREATE INDEX IF NOT EXISTS idx_articles_scraped ON articles(scraped_at);
    ''')
    conn.commit()
    conn.close()
    log.info("DB initialized")

# ── Scraper ───────────────────────────────────────────────────────────────────
class ContentExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.texts = []
        self.links = []
        self.skip_tags = {'script', 'style', 'nav', 'footer', 'header', 'meta', 'noscript'}
        self._skip = False
        self._current_tag = ''
        self._current_href = ''

    def handle_starttag(self, tag, attrs):
        self._current_tag = tag
        if tag in self.skip_tags:
            self._skip = True
        if tag == 'a':
            attrs_d = dict(attrs)
            self._current_href = attrs_d.get('href', '')

    def handle_endtag(self, tag):
        if tag in self.skip_tags:
            self._skip = False
        if tag == 'a':
            self._current_href = ''

    def handle_data(self, data):
        if self._skip:
            return
        text = data.strip()
        if len(text) > 20:
            self.texts.append(text)
            if self._current_href and self._current_tag == 'a':
                self.links.append((text, self._current_href))

def extract_items(html, base_url):
    """Extract meaningful content blocks from HTML."""
    parser = ContentExtractor()
    parser.feed(html)

    base = '/'.join(base_url.split('/')[:3])
    items = []

    # Keywords suggesting relevant content
    keywords = ['aide', 'subvention', 'appel', 'financement', 'projet', 'soutien',
                'dispositif', 'programme', 'fonds', 'investissement', 'capex', 'grant']

    for text, href in parser.links:
        text_lower = text.lower()
        if any(k in text_lower for k in keywords) and len(text) > 15:
            full_url = href if href.startswith('http') else base + href if href.startswith('/') else base_url + '/' + href
            items.append({'title': text.strip(), 'url': full_url})

    # If no links found, extract text blocks
    if not items:
        for text in parser.texts:
            text_lower = text.lower()
            if any(k in text_lower for k in keywords) and 20 < len(text) < 300:
                items.append({'title': text.strip(), 'url': base_url})

    return items[:15]  # Max 15 items per source

def scrape_source(source):
    """Scrape a single source and return new articles."""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0',
        'Accept-Language': 'fr-FR,fr;q=0.9',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    }

    try:
        req = Request(source['url'], headers=headers)
        with urlopen(req, timeout=15) as resp:
            html = resp.read(200000).decode('utf-8', errors='ignore')

        # Hash full page content to detect changes
        content_hash = hashlib.md5(html.encode()).hexdigest()

        conn = get_db()

        # Check if content changed
        snap = conn.execute('SELECT content_hash FROM snapshots WHERE source_url = ?', (source['url'],)).fetchone()

        if snap and snap['content_hash'] == content_hash:
            conn.execute('UPDATE snapshots SET last_checked = CURRENT_TIMESTAMP, status = ? WHERE source_url = ?',
                        ('ok', source['url']))
            conn.commit()
            conn.close()
            return 0  # No change

        # Content changed or first visit — extract items
        items = extract_items(html, source['url'])
        new_count = 0

        for item in items:
            art_hash = hashlib.md5(f"{source['url']}:{item['title']}".encode()).hexdigest()
            try:
                conn.execute('''
                    INSERT OR IGNORE INTO articles (hash, title, url, source, cat, region, color, source_url, scraped_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ''', (art_hash, item['title'], item['url'], source['name'],
                      source['cat'], source.get('region', ''),
                      CAT_COLORS.get(source['cat'], '#4b5a75'), source['url']))
                if conn.total_changes > 0:
                    new_count += 1
            except Exception:
                pass

        # Update snapshot
        conn.execute('''
            INSERT OR REPLACE INTO snapshots (source_url, content_hash, last_checked, status, error_count)
            VALUES (?, ?, CURRENT_TIMESTAMP, 'ok', 0)
        ''', (source['url'], content_hash))
        conn.commit()
        conn.close()
        return new_count

    except Exception as e:
        log.warning(f"Error scraping {source['name']}: {e}")
        conn = get_db()
        conn.execute('''
            INSERT OR REPLACE INTO snapshots (source_url, content_hash, last_checked, status, error_count)
            VALUES (?, '', CURRENT_TIMESTAMP, 'error',
                COALESCE((SELECT error_count FROM snapshots WHERE source_url = ?), 0) + 1)
        ''', (source['url'], source['url']))
        conn.commit()
        conn.close()
        return 0

def run_scraper():
    """Run full scraping cycle."""
    log.info(f"Starting scrape cycle — {len(SOURCES)} sources")
    total_new = 0
    for i, source in enumerate(SOURCES):
        new = scrape_source(source)
        total_new += new
        if new > 0:
            log.info(f"[{i+1}/{len(SOURCES)}] {source['name']}: {new} new items")
        time.sleep(0.5)  # Be polite
    log.info(f"Scrape complete — {total_new} new articles total")
    return total_new

# ── API Routes ─────────────────────────────────────────────────────────────────
@app.route('/api/articles')
def get_articles():
    cat = request.args.get('cat')
    region = request.args.get('region')
    search = request.args.get('q')
    page = int(request.args.get('page', 0))
    limit = int(request.args.get('limit', 60))

    query = 'SELECT * FROM articles WHERE 1=1'
    params = []

    if cat:
        query += ' AND cat = ?'
        params.append(cat)
    if region:
        query += ' AND region = ?'
        params.append(region)
    if search:
        query += ' AND (title LIKE ? OR source LIKE ? OR region LIKE ?)'
        s = f'%{search}%'
        params.extend([s, s, s])

    query += ' ORDER BY scraped_at DESC LIMIT ? OFFSET ?'
    params.extend([limit, page * limit])

    conn = get_db()
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route('/api/stats')
def get_stats():
    conn = get_db()
    today = datetime.now().strftime('%Y-%m-%d')
    stats = {
        'total': conn.execute('SELECT COUNT(*) FROM articles').fetchone()[0],
        'today': conn.execute("SELECT COUNT(*) FROM articles WHERE scraped_at LIKE ?", (f'{today}%',)).fetchone()[0],
        'sources_ok': conn.execute("SELECT COUNT(*) FROM snapshots WHERE status = 'ok'").fetchone()[0],
        'sources_error': conn.execute("SELECT COUNT(*) FROM snapshots WHERE status = 'error'").fetchone()[0],
        'sources_total': len(SOURCES),
        'last_scrape': conn.execute("SELECT MAX(last_checked) FROM snapshots").fetchone()[0],
    }
    conn.close()
    return jsonify(stats)

@app.route('/api/categories')
def get_categories():
    conn = get_db()
    cats = conn.execute('SELECT DISTINCT cat, COUNT(*) as count FROM articles GROUP BY cat ORDER BY count DESC').fetchall()
    conn.close()
    return jsonify([{'cat': r['cat'], 'count': r['count'], 'color': CAT_COLORS.get(r['cat'], '#4b5a75')} for r in cats])

@app.route('/api/scrape', methods=['POST'])
def trigger_scrape():
    """Manual scrape trigger."""
    t = threading.Thread(target=run_scraper)
    t.daemon = True
    t.start()
    return jsonify({'status': 'started', 'sources': len(SOURCES)})

@app.route('/api/health')
def health():
    return jsonify({'status': 'ok', 'sources': len(SOURCES), 'time': datetime.now().isoformat()})

@app.route('/')
def index():
    return jsonify({'app': 'SubstanCiel Veille API', 'version': '1.0', 'endpoints': ['/api/articles', '/api/stats', '/api/categories', '/api/scrape', '/api/health']})

# ── Scheduler ─────────────────────────────────────────────────────────────────
def start_scheduler():
    scheduler = BackgroundScheduler()
    scheduler.add_job(run_scraper, 'interval', hours=6, id='scraper')
    scheduler.start()
    log.info("Scheduler started — scraping every 6 hours")

# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    init_db()
    # Initial scrape in background
    t = threading.Thread(target=run_scraper)
    t.daemon = True
    t.start()
    start_scheduler()
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
else:
    init_db()
    start_scheduler()
    # Initial scrape
    t = threading.Thread(target=run_scraper)
    t.daemon = True
    t.start()
