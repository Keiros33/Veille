# SubstanCiel Veille — Guide de déploiement

## Architecture
```
GitHub (code) → Render.com (serveur gratuit) → index.html (interface)
```

---

## ÉTAPE 1 — Mettre le code sur GitHub

1. Allez sur **github.com** → "New repository"
2. Nommez-le `veille-substanciel`
3. Cliquez **"uploading an existing file"**
4. Glissez-déposez les fichiers : `app.py`, `requirements.txt`, `render.yaml`
5. Cliquez **"Commit changes"**

---

## ÉTAPE 2 — Déployer sur Render.com

1. Allez sur **render.com** → créez un compte gratuit
2. Cliquez **"New +"** → **"Web Service"**
3. Connectez votre compte GitHub
4. Sélectionnez le repo `veille-substanciel`
5. Render détecte automatiquement la config grâce au `render.yaml`
6. Cliquez **"Create Web Service"**
7. Attendez 2-3 minutes que le déploiement se termine
8. Copiez l'URL fournie (ex: `https://veille-substanciel.onrender.com`)

---

## ÉTAPE 3 — Ouvrir l'interface

1. Ouvrez le fichier `index.html` dans votre navigateur
2. Collez l'URL Render dans le champ de configuration
3. Cliquez "Connexion"
4. Le scraper tourne automatiquement — les premiers articles apparaissent en quelques minutes

---

## Fonctionnement

- **Scraping automatique** toutes les 6 heures
- **85 sources** surveillées (régions, DREETS, départements, opérateurs nationaux...)
- **Détection de changements** : seul le contenu nouveau est remonté
- **Base de données SQLite** stockée sur le serveur Render

## Limites du plan gratuit Render

- Le serveur "s'endort" après 15 min d'inactivité
- Se réveille automatiquement dès que vous ouvrez l'interface (~30 secondes)
- Pour éviter ça : upgrade à 7$/mois ou utiliser UptimeRobot (gratuit) pour le garder actif

---

## Ajouter des sources

Ouvrez `app.py` et ajoutez dans le tableau `SOURCES` :
```python
{"name": "Nom", "cat": "Catégorie", "region": "Région", "url": "https://..."},
```
Puis faites un nouveau commit sur GitHub → Render redéploie automatiquement.
